export const server = 'https://officezens-backend.vercel.app'
// export const server = 'http://localhost:4000'


